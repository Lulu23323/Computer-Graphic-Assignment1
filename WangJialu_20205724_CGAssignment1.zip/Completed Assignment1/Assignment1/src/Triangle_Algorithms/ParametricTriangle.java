package Triangle_Algorithms;

import java.awt.Color;
import java.awt.Graphics;

import GraphicsObjects.Point3f;
import GraphicsObjects.Vector3f;

public class ParametricTriangle {

	public Point3f A;
	public Point3f B;
	public Point3f C;

	public ParametricTriangle(Point3f a, Point3f b, Point3f c) {
		A = a;
		B = b;
		C = c;
	}

	float colorA_R,colorB_R,colorC_R;
	float colorA_G,colorB_G,colorC_G;
	float colorA_B,colorB_B,colorC_B;


	//This METHOD IS used TO set the color
	// of the pixel, which defaults to a monochrome triangle
	public void setColor(float r,float g,float b){
		colorA_R=colorB_R=colorC_R = r/255f;
		colorA_G=colorB_G=colorC_G = g/255f;
		colorA_B=colorB_B=colorC_B = b/255f;
	}
	//This method sets the triangle to three colors and
	// then implements the gradient in the following method
	public void setGradient(Color a, Color b, Color c){
		colorA_R = a.getRed()/255f;
		colorA_G = a.getGreen()/255f;
		colorA_B = a.getBlue()/255f;
		colorB_R = b.getRed()/255f;
		colorB_G = b.getGreen()/255f;
		colorB_B = b.getBlue()/255f;
		colorC_R = c.getRed()/255f;
		colorC_G = c.getGreen()/255f;
		colorC_B = c.getBlue()/255f;

	}

	// Implement in Parametric form ,and comment what it does
	//This method uses a parametric algorithm to draw a triangle,
	// in which he sets three parameters, each representing the
	// ratio of the distance between the current point and one
	// side of the triangle to the distance between that side and its opposite point
	//Based on these three values, we can determine whether the
	// current point is inside the triangle. That is, when a parameter
	// value is less than zero, it means that the current point and the
	// triangle endpoint corresponding to this parameter are not on the
	// same side of the opposite side of this endpoint, that is to say,
	// the current point is outside the triangle

	//When S is inside triangle I, we can use these three parameter
	// values to mix colors. All three values represent the ratio of
	// the distance from the current point to the three edges and the
	// distance from the endpoint to the three edges. When the three
	// endpoints are the three colors set before, the RGB of the color
	// of the current point should be proportionally changed according
	// to the ratio of the distance

	public void drawTriangle(Graphics g) {
		float xMin, xMax, yMax, yMin;
		float alpha, gamma, beta;
		Point3f p = new Point3f(0.0f,0.0f,0.0f);
		xMin = findMin(A.x,B.x,C.x);
		xMax = findMax(A.x,B.x,C.x);
		yMin = findMin(A.y,B.y,C.y);
		yMax = findMax(A.y,B.y,C.y);
		for(float x=xMin; x<xMax; x++){
			for(float y = yMin; y<yMax; y++){
				p.x = x;
				p.y = y;
				alpha = Distance(p,B,C)/Distance(A,B,C);
				gamma = Distance(p,A,B)/Distance(C,A,B);
				beta = 1 - alpha - gamma;
				if((alpha>=0.0f)&&(beta>=0.0f)&&(gamma>=0.0f)){
					float cR = alpha*colorA_R + beta*colorB_R + gamma*colorC_R;
					float cG = alpha*colorA_G + beta*colorB_G + gamma*colorC_G;
					float cB = alpha*colorA_B + beta*colorB_B + gamma*colorC_B;
					setPixel(g, (int) x, (int) y,cR,cG,cB);
				}
			}
		}
		 
	}

	//This method is to find the minimum value of x and y from the x coordinates of the three points
	private float findMin(float a, float b, float c){
		float min;
		if(a<=b){
			if(c<=a){
				min = c;
			}else{
				min = a;
			}
		}else{
			if(c<=b){
				min = c;

			}else{
				min = b;
			}
		}
		return min;
	}

	//This method is to find the maximum value of x and y from the x coordinates of the three points
	private float findMax(float a, float b, float c){
		float max;
		if(a<=b){
			if(b<=c){
				max = c;
			}else{
				max = b;
			}
		}else{
			if(c<=a){
				max = a;

			}else{
				max = c;
			}
		}
		return max;
	}

	//I have implemented this method to adapt Swings coordinate system 
	public void setPixel(Graphics g, int x, int y, float R, float G, float B) {
 
		Color pixelColour = new Color(R, G, B);
		g.setColor(pixelColour);
		g.drawRect(x + 500, 500 - y, 1, 1); // + 500 offset is to make the
											// centre 0,0 at centre of the
											// screen

	}

	//Implement the distance ,  you may use your previous Distance formulas and comment what it does 
	public float Distance(Point3f Check, Point3f Beginning, Point3f End) {
		float A = End.y-Beginning.y;
		float B = Beginning.x-End.x;
		float C = Beginning.y*End.x - Beginning.x*End.y;
		float d = (float) ((A* Check.x + B* Check.y + C)/Math.sqrt (Math.pow(A,2) + Math.pow(B,2)));
		return d;

	}

}
