package GraphicsObjects;



public class Vector3f {

	public float x=0;
	public float y=0;
	public float z=0;

	//This is a default constructor
	public Vector3f() 
	{  
		x = 0.0f;
		y = 0.0f;
		z = 0.0f;
	}
	 
	public Vector3f(float x, float y, float z) 
	{ 
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	 //implement Vector plus a Vector  and comment what the method does
	//Vector plus vector gives you a new vector, and the function gives
	 // you the coordinates of the new vector algebraically, and geometrically,
	 // the new vector can be obtained by the parallelogram rule or the triangle rule
	public Vector3f PlusVector(Vector3f Additonal) 
	{
		Vector3f result = new Vector3f(0.0f, 0.0f, 0.0f);
		result.x = this.x + Additonal.x;
		result.y = this.y + Additonal.y;
		result.z = this.z + Additonal.z;
		return result;
	} 
	
	 //implement Vector minus a Vector  and comment what the method does
	//Vector is presupposed, a vector can be found here using algebraic
	 // method, geometric, parallelogram rule can be applied to solve:
	 // two vector translation to public starting point, the two sides
	 // of a parallelogram as vectors, and the results by the end of the
	 // vector reduction to decrease was the end of the vector
	 // (parallelogram rule only applies to two non-zero non collinear vectors add and subtract
	public Vector3f MinusVector(Vector3f Minus) 
	{   Vector3f result = new Vector3f(0.0f, 0.0f, 0.0f);
		result.x = this.x - Minus.x;
		result.y = this.y - Minus.y;
		result.z = this.z - Minus.z;
		return result;
	}
	
	//implement Vector plus a Point and comment what the method does
	//When you add a vector to a point, you take the point along the
	// vector, you move the magnitude of the vector, and you get an endpoint
	public Point3f PlusPoint(Point3f Additonal)
	{   Point3f result = new Point3f(0.0f,0.0f,0.0f);
		result.x = this.x + Additonal.x;
		result.y = this.y + Additonal.y;
		result.z = this.z + Additonal.z;
		return result;
	} 
	//Do not implement Vector minus a Point as it is undefined

	
	//Implement a Vector * Scalar  and comment what the method does    ( we wont create Scalar * Vector due to expediency )
	//Scalar multiplication is a fundamental operation defined by vector Spaces in linear algebra. In the usual concept of
	// geometry, the magnitude of a vector is multiplied without changing its orientation by scalar multiplication of
	// Euclidean vectors of positive real numbers.
	public Vector3f byScalar(float scale )
	{
		this.x = this.x * scale;
		this.y = this.y * scale;
		this.z = this.z * scale;
		return this;
	}
	
	//implement returning the negative of a Vector  and comment what the method does
	//The opposite of a vector is when you leave the length of the vector unchanged,
	// but the direction is reversed. So numerically everything is going to be the
	// opposite of what it was before
	public Vector3f  NegateVector()
	{   this.x = this.x * -1;
		this.y = this.y * -1;
		this.z = this.z * -1;
		return this;
	}
	
	//implement getting the length of a Vector    and comment what the method does
	//We use the law of cosines to find the magnitude of the vector which is
	// the length of the vector
	public float length()
	{
		return (float) Math.sqrt (Math.pow(this.x,2) + Math.pow(this.y,2) + Math.pow(this.z,2));
	}
	
	//implement getting the Normal  of a Vector   and comment what the method does
	// Remember that since you just have one vector, this method is returning a normalized vector with a one unity length
	//This method yields the coordinates of a vector of length 1 in the direction of that vector, the unit vector. In this
	// method, the length of the unit vector is obtained first, and then the coordinates of the unit vector are divided by
	// the length of the module
	public Vector3f Normal()
	{
		Vector3f normal = new Vector3f(0.0f,0.0f,0.0f);
		float l = this.length();
		normal.x = this.x/l;
		normal.y = this.y/l;
		normal.z = this.z/l;
		return normal;
	} 
	
	//implement getting the dot product of Vector.Vector and comment what the method does
	//This method gives you the answer to the dot product of the vectors, the dot product
	// of two vectors, the sum of the corresponding bits of the two vectors, the dot product is a scalar.
	public float dot(Vector3f v)
	{
		float result = this.x * v.x + this.y * v.y + this.z * v.z;
		return result;
	}
	
	//implement getting the cross product of Vector X Vector and comment what the method does
	//This method gives you the answer to the vector CHA, the cross product is a vector instead
	// of a scalar. And the cross product of two vectors is perpendicular to the coordinate plane
	// of these two vectors.
	public Vector3f cross(Vector3f v)  
	{
		Vector3f result = new Vector3f(0.0f, 0.0f, 0.0f);
		result.x = this.y * v.z - this.z * v.y;
		result.y = this.z * v.x - this.x * v.z;
		result.z = this.x * v.y - this.y * v.x;
		return result;
	}
 
}
	 
	   

/*

										MMMM                                        
										MMMMMM                                      
 										MM MMMM                                    
 										MMI  MMMM                                  
 										MMM    MMMM                                
 										MMM      MMMM                              
  										MM        MMMMM                           
  										MMM         MMMMM                         
  										MMM           OMMMM                       
   										MM             .MMMM                     
MMMMMMMMMMMMMMM                        MMM              .MMMM                   
MM   IMMMMMMMMMMMMMMMMMMMMMMMM         MMM                 MMMM                 
MM                  ~MMMMMMMMMMMMMMMMMMMMM                   MMMM               
MM                                  OMMMMM                     MMMMM            
MM                                                               MMMMM          
MM                                                                 MMMMM        
MM                                                                   ~MMMM      
MM                                                                     =MMMM    
MM                                                                        MMMM  
MM                                                                       MMMMMM 
MM                                                                     MMMMMMMM 
MM                                                                  :MMMMMMMM   
MM                                                                MMMMMMMMM     
MM                                                              MMMMMMMMM       
MM                             ,MMMMMMMMMM                    MMMMMMMMM         
MM              IMMMMMMMMMMMMMMMMMMMMMMMMM                  MMMMMMMM            
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM               ZMMMMMMMM              
MMMMMMMMMMMMMMMMMMMMMMMMMMMMM          MM$             MMMMMMMMM                
MMMMMMMMMMMMMM                       MMM            MMMMMMMMM                  
  									MMM          MMMMMMMM                     
  									MM~       IMMMMMMMM                       
  									MM      DMMMMMMMM                         
 								MMM    MMMMMMMMM                           
 								MMD  MMMMMMMM                              
								MMM MMMMMMMM                                
								MMMMMMMMMM                                  
								MMMMMMMM                                    
  								MMMM                                      
  								MM                                        
                             GlassGiant.com */