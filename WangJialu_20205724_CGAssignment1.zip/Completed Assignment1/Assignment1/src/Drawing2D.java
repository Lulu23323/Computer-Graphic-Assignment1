import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

import GraphicsObjects.Point3f;
import GraphicsObjects.Vector3f;
import Line_Algorithms.ExplicitLine;
import Line_Algorithms.ImplicitLine;
import Line_Algorithms.ParametricLine;
import Triangle_Algorithms.ParametricTriangle;

/*
 * 
 * This class to test your work and for you to make lines to draw your house , it will not compile till all the methods are complete in the other classes 
 * 
 */
public class Drawing2D extends JPanel {

	public Drawing2D() // set up graphics window
	{
		setBackground(Color.WHITE);

	}
	public void paintComponent(Graphics g) // draw graphics in the panel
	{
		int width = getWidth(); // width of window in pixels
		int height = getHeight(); // height of window in pixels

		// as swing starts at 0 , 0 , will need to modify drawing

		super.paintComponent(g); // call superclass to make panel display
									// correctly

		g.setColor(Color.BLACK);
		
		//line test code 
//
//		ExplicitLine FirstLine = new ExplicitLine(new Point3f(0, 0, 0), new Point3f(200, 100, 0));
//		ImplicitLine SecondLine = new ImplicitLine(new Point3f(0, 0, 0), new Point3f(200, 200, 0)); // 200
//		ParametricLine ThirdLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(75, 200, 0));
//
//		FirstLine.drawLine(g);
//		SecondLine.drawLine(g);
//		ThirdLine.drawLine(g);

		// Remove the comments for Explicit line and test it ,
//
//		ExplicitLine FirstLine = new ExplicitLine(new Point3f(0, 0, 0), new Point3f(200, 100, 0));
//		ExplicitLine SecondLine = new ExplicitLine(new Point3f(0, 0, 0), new Point3f(200, 200, 0)); // 200
//		ExplicitLine ThirdLine = new ExplicitLine(new Point3f(0, 0, 0), new Point3f(75, 200, 0));
//		ExplicitLine FourthLine = new ExplicitLine(new Point3f(0, 0, 0), new Point3f(25, 200, 0));
//
//		FirstLine.drawLine(g);
//		SecondLine.drawLine(g);
//		ThirdLine.drawLine(g);
//		FourthLine.drawLine(g);

		//

		// Remove the comments for Implicit line and test it

//		ImplicitLine FirstLine = new ImplicitLine(new Point3f(0, 0, 0), new Point3f(200, 100, 0));
//		ImplicitLine SecondLine = new ImplicitLine(new Point3f(0, 0, 0), new Point3f(200, 200, 0));
//		ImplicitLine ThirdLine = new ImplicitLine(new Point3f(0, 0, 0), new Point3f(75, 200, 0));
//		ImplicitLine FourthLine = new ImplicitLine(new Point3f(0, 0, 0), new Point3f(25, 200, 0));
//
//		FirstLine.drawLine(g);
//		SecondLine.drawLine(g);
//		ThirdLine.drawLine(g);
//		FourthLine.drawLine(g);

		// Remove the comments for Parametric line and test it
//
//		ParametricLine FirstLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(200, 100, 0));
//		ParametricLine SecondLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(200, 200, 0));
//		ParametricLine ThirdLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(75, 200, 0));
//		ParametricLine FourthLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(25, 200, 0));
//
//		FirstLine.drawLine(g);
//		SecondLine.drawLine(g);
//		ThirdLine.drawLine(g);
//		FourthLine.drawLine(g);


		// Remove the comments for an example of square using Parametric lines
//		ParametricLine FirstLine = new ParametricLine(new Point3f(0, 0, 0), new Point3f(0, 300, 0));
//		ParametricLine SecondLine = new ParametricLine(new Point3f(0, 300, 0), new Point3f(300, 300, 0));
//		ParametricLine ThirdLine = new ParametricLine(new Point3f(300, 300, 0), new Point3f(300, 0, 0));
//		ParametricLine FourthLine = new ParametricLine(new Point3f(300, 0, 0), new Point3f(0, 0, 0));
//
//		FirstLine.drawLine(g);
//		SecondLine.drawLine(g);
//		ThirdLine.drawLine(g);
//		FourthLine.drawLine(g);
//
//		ParametricTriangle MyFirstTriangle = new ParametricTriangle(new Point3f(100, 0, 0), new Point3f(400,200, 0), new Point3f(200, 370, 0));
//		MyFirstTriangle.setGradient(new Color(182,194,167),new Color(255,197,97),new Color(182,197,167));
//		 MyFirstTriangle.drawTriangle(g);
//
		//insert your house drawings  here
		//background
		//This is how you draw the background.
		// The background is made by concatenating
		// two triangles, one of which is a solid
		// color triangle and the other is a gradient triangle
		ParametricTriangle Background_p1 = new ParametricTriangle(new Point3f(-600, -600, 0), new Point3f(600,-600, 0), new Point3f(600, 600, 0));
		ParametricTriangle Background_p2 = new ParametricTriangle(new Point3f(-600, -600, 0), new Point3f(-600,600, 0), new Point3f(600, 600, 0));
		Background_p2.setGradient(new Color(182,194,167),new Color(255,197,97),new Color(182,197,167));
		Background_p1.setColor(182,194,167);
		Background_p1.drawTriangle(g);
		Background_p2.drawTriangle(g);


		//tree
		//This is the method of drawing a tree. The trunk
		// is made by joining two triangles, while the leaves
		// are three congruent triangles. Therefore, when drawing
		// the leaves, I apply the method of point and vector
		// multiplication to shift the coordinates of the triangle
		// upward by an appropriate amount of units to realize the
		// replication of the triangle
		ParametricTriangle Trunk_p1 = new ParametricTriangle(new Point3f(-408, -260, 0), new Point3f(-378,-260, 0), new Point3f(-378, -130, 0));
		ParametricTriangle Trunk_p2 = new ParametricTriangle(new Point3f(-408, -260, 0), new Point3f(-408,-130, 0), new Point3f(-378, -130, 0));
		Trunk_p1.setColor(49,42,24);
		Trunk_p2.setColor(49,42,24);
		Trunk_p1.drawTriangle(g);
		Trunk_p2.drawTriangle(g);

		for(float i=0; i<3; i++){
			ParametricTriangle Leaves = new ParametricTriangle(new Point3f(-393, -30+100*i, 0), new Point3f(-493,-130+100*i, 0), new Point3f(-293, -130+100*i, 0));
			Leaves.setColor(101,101,64);
			Leaves.drawTriangle(g);
		}

		//The roof
		ParametricTriangle Roof = new ParametricTriangle(new Point3f(-120, 140, 0), new Point3f(-420, 0, 0), new Point3f(180,0, 0));
		Roof.setColor(45,38,19);
		Roof.drawTriangle(g);
		//House body
		ParametricTriangle House_p1 = new ParametricTriangle(new Point3f(-348, 0, 0), new Point3f(108,0, 0), new Point3f(-348, -260, 0));
		ParametricTriangle House_p2 = new ParametricTriangle(new Point3f(108, -260, 0), new Point3f(108,0, 0), new Point3f(-348, -260, 0));
		House_p1.setColor(213,146,93);
		House_p2.setColor(213,146,93);
		House_p1.drawTriangle(g);
		House_p2.drawTriangle(g);
		//Metope adornment
		ParametricTriangle Wall_p1 = new ParametricTriangle(new Point3f(-348, -200, 0), new Point3f(-348,-260, 0), new Point3f(108, -200, 0));
		ParametricTriangle Wall_p2 = new ParametricTriangle(new Point3f(108, -260, 0), new Point3f(-348,-260, 0), new Point3f(108, -200, 0));
		Wall_p1.setColor(121,105,75);
		Wall_p2.setColor(121,105,75);
		Wall_p1.drawTriangle(g);
		Wall_p2.drawTriangle(g);
		//Door
		ParametricTriangle Gate_p1 = new ParametricTriangle(new Point3f(-170, -260, 0), new Point3f(-170,-60, 0), new Point3f(-70, -60, 0));
		ParametricTriangle Gate_p2 = new ParametricTriangle(new Point3f(-170, -260, 0), new Point3f(-70,-260, 0), new Point3f(-70, -60, 0));
		Gate_p1.setColor(45,38,19);
		Gate_p2.setColor(45,38,19);
		Gate_p1.drawTriangle(g);
		Gate_p2.drawTriangle(g);

		//Left window
		ParametricTriangle Window_Lp1 = new ParametricTriangle(new Point3f(-280, -180, 0), new Point3f(-230,-180, 0), new Point3f(-230, -35, 0));
		ParametricTriangle Window_Lp2 = new ParametricTriangle(new Point3f(-280, -180, 0), new Point3f(-280,-35, 0), new Point3f(-230, -35, 0));
		Window_Lp1.setColor(45,38,19);
		Window_Lp2.setColor(45,38,19);
		Window_Lp1.drawTriangle(g);
		Window_Lp2.drawTriangle(g);
		//The sash of the left window
		ParametricLine lline_1 = new ParametricLine(new Point3f(-280f,-107.5f,0f),new Point3f(-230f,-107.5f,0f));
		ParametricLine lline_2 = new ParametricLine(new Point3f(-255f,-35f,0f),new Point3f(-255f,-180f,0f));
		lline_1.setColor(213,146,93);
		lline_1.drawLine(g);
		lline_2.setColor(213,146,93);
		lline_2.drawLine(g);

		//Right window
		ParametricTriangle Window_Rp1 = new ParametricTriangle(new Point3f(40, -35, 0), new Point3f(-10,-35, 0), new Point3f(-10, -180, 0));
		ParametricTriangle Window_Rp2 = new ParametricTriangle(new Point3f(40, -35, 0), new Point3f(40,-180, 0), new Point3f(-10, -180, 0));
		Window_Rp1.setColor(45,38,19);
		Window_Rp2.setColor(45,38,19);
		Window_Rp1.drawTriangle(g);
		Window_Rp2.drawTriangle(g);
		//The sash of the right window
		ParametricLine rline_1 = new ParametricLine(new Point3f(15f,-35f,0f),new Point3f(15f,-180f,0f));
		ParametricLine rline_2 = new ParametricLine(new Point3f(40f,-107.5f,0f),new Point3f(-10f,-107.5f,0f));
		rline_1.setColor(213,146,93);
		rline_1.drawLine(g);
		rline_2.setColor(213,146,93);
		rline_2.drawLine(g);

		//ground
		ParametricTriangle Ground_p1 = new ParametricTriangle(new Point3f(-1000, -260, 0), new Point3f(1000,-260, 0), new Point3f(1000, -1000, 0));
		ParametricTriangle Ground_p2 = new ParametricTriangle(new Point3f(-1000, -260, 0), new Point3f(1000,-1000, 0), new Point3f(-1000, -1000, 0));
		Ground_p1.setColor(212,206,135);
		Ground_p2.setColor(212,206,135);
		Ground_p1.drawTriangle(g);
		Ground_p2.drawTriangle(g);

		//Roof texture
		//According to the three endpoints using
		// point and point of the triangle is presupposed
		// by the method of vector for roof triangle with
		// the two side of the vector, using point and vector
		// multiplication of geometric meaning, and the
		// roof to the end of the two bottom edge of the
		// triangle as a starting point, upward in a certain
		// interval translation, every translation is one of
		// these two points to draw a line for the endpoint,
		// until you reach the roof of the triangle vertex positions
		Point3f top = Roof.A;
		Point3f left = Roof.B;
		Point3f right = Roof.C;
		Vector3f v_l = top.MinusPoint(left);
		Vector3f v_r = top.MinusPoint(right);
		for(float i=140f;i>=0f;i-=10f){
			Point3f topMoveLeft = top.MinusVector(v_l.byScalar(i/140f));
			Point3f topMoveRight = top.MinusVector(v_r.byScalar(i/140f));
			ExplicitLine texture = new ExplicitLine(topMoveLeft,topMoveRight);
			texture.setColor(145,117,102);
			texture.drawLine(g);
		}


		//tree2
		ParametricTriangle Trunk2_p1 = new ParametricTriangle(new Point3f(190, -260, 0), new Point3f(165,-260, 0), new Point3f(190, -180, 0));
		ParametricTriangle Trunk2_p2 = new ParametricTriangle(new Point3f(165, -180, 0), new Point3f(165,-260, 0), new Point3f(190, -180, 0));
		Trunk2_p1.setColor(49,42,24);
		Trunk2_p2.setColor(49,42,24);
		Trunk2_p1.drawTriangle(g);
		Trunk2_p2.drawTriangle(g);

		for(float i=0; i<3; i++){
			ParametricTriangle Leaves = new ParametricTriangle(new Point3f(240, -180+50*i, 0), new Point3f(110,-180+50*i, 0), new Point3f(175, -130+50*i, 0));
			Leaves.setColor(206,206,131);
			Leaves.drawTriangle(g);
		}


		//grass
		//It also uses the geometric meaning of point and vector multiplication to realize grass replication
		for(float i=0; i<40; i++){
			ParametricTriangle Grass = new ParametricTriangle(new Point3f(108+10*i, -260, 0), new Point3f(113+10*i,-230, 0), new Point3f(118+10*i, -260, 0));
			Grass.setColor(174,182,111);
			Grass.drawTriangle(g);
		}
		//draw the sun
		Circular sun = new Circular(new Point3f(-378,400, 0),60);
		sun.setColor(254,164,73);
		sun.drawCircle(g);

	}

	public static void main(String[] args) {
		Drawing2D panel = new Drawing2D();
		JFrame ScreenToDrawOn = new JFrame();
		ScreenToDrawOn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ScreenToDrawOn.setTitle("2D Drawing Application");
		ScreenToDrawOn.setSize(600, 600); // window is 500 pixels wide, 400 high
		ScreenToDrawOn.setVisible(true);
		ScreenToDrawOn.add(panel);

	}

}
