import java.awt.Color;
import java.awt.Graphics;

import GraphicsObjects.Point3f;
public class Circular {
    //This method uses an algorithm called Implicit to draw a circle
    //This point is the center of the circle
    public Point3f center;

    //This number represents the radius of the circle
    public float r;
    float R=0.0f;
    float G=0.0f;
    float B=0.0f;


    //Construct the circle
    public Circular(Point3f a, float b) {
        center = a;
        r = b;
    }

    //Enter the color of the circle and set
    // RGB to be called in the following method
    public void setColor(float r,float g,float b) {
        R = r / 255f;
        G = g / 255f;
        B = b / 255f;
    }

    //This method is used to draw circles by placing the circle
    // in a box and then traversing the points in the box at regular
    // intervals to determine the distance between the points and
    // the center of the circle. If the distance is less than or
    // equal to the radius, the point is inside the circle.
    // Set a pixel on the point, otherwise ignore it.
    public void drawCircle(Graphics g){
        Color pixelColour = new Color(R, G, B);
        g.setColor(pixelColour);
        float xMin = center.x-Math.abs(r);
        float xMax = center.x+Math.abs(r);
        float yMin = center.y-Math.abs(r);
        float yMax = center.y+Math.abs(r);
        Point3f p = new Point3f(0.0f,0.0f,0.0f);
        for(float x = xMin; x < xMax; x+=0.1f){
            for(float y = yMin; y<yMax; y+=0.1f){
                p.x = x;
                p.y = y;
                if(Math.abs(Distance(p,center))<=r){
                    setPixel(g,(int)x,(int)y);
                }
            }
        }
    }

    //I have implemented this method to adapt Swings coordinate system
    public void setPixel(Graphics g, int x, int y) {

        Color pixelColour = new Color(R, G, B);
        g.setColor(pixelColour);
        g.drawRect(x + 500, 500 - y, 1, 1); // + 500 offset is to make the
        // centre 0,0 at centre of the
        // screen

    }

    //Implement the distance ,  you may use your previous Distance formulas and comment what it does
    //This method uses the distance formula between two
    // points to calculate the distance between two points
    public float Distance(Point3f Check, Point3f Center) {
        float d = (float) Math.sqrt (Math.pow((Check.x-Center.x),2) + Math.pow((Check.y-Center.y),2));
        return d;

    }

}
