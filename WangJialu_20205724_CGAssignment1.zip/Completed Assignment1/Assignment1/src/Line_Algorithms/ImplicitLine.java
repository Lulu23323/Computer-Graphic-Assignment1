package Line_Algorithms;

import java.awt.Color;
import java.awt.Graphics;

import GraphicsObjects.Point3f;
import GraphicsObjects.Vector3f;

public class ImplicitLine {

	Point3f Start;
	Point3f End;
	float R=0.0f,G=0.0f,B=0.0f;
	public void setColor(float r, float g, float b){
		this.R = r/255f;
		this.G = g/255f;
		this.B = b/255f;
	}

	public ImplicitLine(Point3f Start, Point3f End) {
		this.Start = Start;
		this.End = End;

	}

	// Implement in Explict form , Extra marks for reducing the search space
	// before you draw the line , and comment what the method does

	//This method employs an algorithm that is Implicit to draw a line
	// segment. It first obtains the maximum and minimum values of x and y
	// from two known points, and then envelopes the segment into a box that
	// is Implicit. Then the points in the box are traversed at a certain
	// interval, and a pixel is set for each point whose distance from the
	// ideal line segment is less than 0.4F, so as to realize the drawing
	// of the line segment

	//In order to optimize the algorithm and reduce the search area,
	// I divided the box into four quadrants, and only needed to search
	// in one or three quadrants to get the desired effect. Therefore,
	// I separated the judgment criteria from the center of X and Y,
	// and made cyclic judgments separately, thus reducing the search area by 1/2
	public void drawLine(Graphics g) {
		Color pixelColour = new Color(R, G, B);
		g.setColor(pixelColour);
		float xMin, xMax, yMax, yMin,xMid,yMid;
		if(Start.x>=End.x){
			xMax = Start.x;
			xMin = End.x;
		}else{
			xMax = End.x;
			xMin = Start.x;
		}
		if(Start.y>=End.y){
			yMax = Start.y;
			yMin = End.y;
		}else{
			yMax = End.y;
			yMin = Start.y;
		}
		Point3f p = new Point3f(0.0f,0.0f,0.0f);
		xMid = (xMin+xMax)/2;
		yMid = (yMin+yMax)/2;
		for(float x = xMin; x < xMid; x+=0.1f){
			for(float y = yMin; y<yMid; y+=0.1f){
				p.x = x;
				p.y = y;
				if(Math.abs(Distance(p,this.Start,this.End))<0.4f){
					setPixel(g,(int)x,(int)y);
				}
			}
		}
		for(float x = xMid; x < xMax; x+=0.1f){
			for(float y = yMid; y<yMax; y+=0.1f){
				p.x = x;
				p.y = y;
				if(Math.abs(Distance(p,this.Start,this.End))<0.4f){
					setPixel(g,(int)x,(int)y);
				}
			}
		}
	}


	//implement Distance formulas using your notes , and comment what the method does

	//This method is used to calculate the distance between a point and a line, using
	// a two-point formula, or algebraic method
	public float Distance(Point3f Check, Point3f Beginning, Point3f End) {
		float A = End.y-Beginning.y;
		float B = Beginning.x-End.x;
		float C = Beginning.y*End.x - Beginning.x*End.y;
		float d = (float) ((A* Check.x + B* Check.y + C)/Math.sqrt (Math.pow(A,2) + Math.pow(B,2)));
		return d;
	}

	// I have implemented this method to adapt Swings coordinate system
	public void setPixel(Graphics g, int x, int y) {
		g.drawRect(x + 500, 500 - y, 1, 1); // + 500 offset is to make the
											// centre 0,0 at centre of the
											// screen
	}

}
