package Line_Algorithms;

import java.awt.Color;
import java.awt.Graphics;

import GraphicsObjects.Point3f;

public class ExplicitLine {
	
	Point3f Start;
	Point3f End;
	float slope;
	float R=0.0f,G=0.0f,B=0.0f;
	//This method is used to set the color of the line
	// segment. The input parameters are traditionally
	// r, g, and b, and this method processes these
	// three parameters into a range that Java can handle
	public void setColor(float r, float g, float b){
		this.R = r/255f;
		this.G = g/255f;
		this.B = b/255f;
	}


	public ExplicitLine(Point3f Start, Point3f End) { 
		this.Start = Start;
		this.End = End;
		slope = getSlope(); // you need to implement this before the class will compile 
	}
	
	// Implement and comment what the method does
	//This method calculates the slope of a segment
	// based on where it starts and where it ends,
	// and the slope is equal to the difference between y and x
	public float getSlope() {return Math.abs(Start.y- End.y)/Math.abs(Start.x- End.x);}
	
	// Implement in Explicit form, and comment what the method does
	//This method uses the Explicit algorithm to draw line segments:
	// first, color is set for each pixel by calling the set color
	// method, and then the color is drawn bottom-up when the slope
	// is less than one point, or top-down when the slope is less
	// than one point, thus avoiding gaps between pixel blocks
	public void drawLine(Graphics g)
	{
		Color pixelColour = new Color(R, G, B);
		g.setColor(pixelColour);
		float c = Start.y - slope * Start.x;
		float b = Start.x - (1/slope) * Start.y;
		float rise = End.y- Start.y;
		float run = End.x - Start.x;
		if(run>0){
			if(rise>0){
				if(run>rise){
					float y;
					for(float x = Start.x; x < End.x; x++){
						y = slope * x + c;
						setPixel(g,(int)x,(int)y);
					}
				}else{
					float x;
					for(float y = Start.y; y < End.y; y++){
						x = (1/slope) * y + b;
						setPixel(g,(int)x,(int)y);
					}
				}
			}else{
				if(run>-rise){
					float y;
					for(float x = Start.x; x < End.x; x++){
						y = slope * x + c;
						setPixel(g,(int)x,(int)y);
					}
				}else{
					float x;
					for(float y = Start.y; y < End.y; y++){
						x = (1/slope) * y + b;
						setPixel(g,(int)x,(int)y);
					}
				}
			}
		}
   
	}
	
	//I have implemented this method to adapt Swings coordinate system 
	public void setPixel(Graphics g,int x,int y)
	{
		g.drawRect(x+500, 500-y, 1,1);  // + 500 offset is to make the centre 0,0 at centre of the screen 
		  
	}

}
