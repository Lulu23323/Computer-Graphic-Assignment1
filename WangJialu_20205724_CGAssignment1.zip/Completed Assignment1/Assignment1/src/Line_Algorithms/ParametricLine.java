package Line_Algorithms;

import java.awt.*;

import GraphicsObjects.Point3f;

public class ParametricLine {

	Point3f Start;
	Point3f End;
	float R=0.0f,G=0.0f,B=0.0f;

	public void setColor(float r, float g, float b){
		this.R = r/255f;
		this.G = g/255f;
		this.B = b/255f;
	}

	public ParametricLine(Point3f Start, Point3f End) {
		this.Start = Start;
		this.End = End;

	}

	// Implement in Parametric form , and comment what it does
	//This method uses a parametric algorithm to draw the line
	// segment: it moves the point forward along the desired line
	// segment a small distance at a time to achieve the line
	// segment. That is, let the ratio of each increment of x and Y
	// of the pixels to the change from the starting point to the
	// ending point be a small constant t
	public void drawLine(Graphics g) {
		Point3f CurrentPoint = Start;
		Color pixelColour = new Color(R, G, B);
		g.setColor(pixelColour);
		for(float t = 0.0f; t <=1.0; t += 0.00001f){
			CurrentPoint.x = Start.x + (End.x- Start.x)*t;
			CurrentPoint.y = Start.y + (End.y- Start.y)*t;
			setPixel(g, (int) CurrentPoint.x, (int) CurrentPoint.y);
		}
	}

	// I have implemented this method to adapt Swings coordinate system
	public void setPixel(Graphics g, int x, int y) {
		g.drawRect(x + 500, 500 - y, 1, 1); // + 500 offset is to make the
											// centre 0,0 at centre of the
											// screen for swing :-)

	}
}
